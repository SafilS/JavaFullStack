package com.example.ems.repository;

public class EmsRepo {
    private int empId;
    private String name;
    private String
}
