package com.example.ems.service;

public class EmsService {
}
